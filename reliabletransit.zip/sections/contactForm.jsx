import React from 'react'

const contactForm = () => {
  return (
    <div>contactForm</div>
  )
}

export default contactForm