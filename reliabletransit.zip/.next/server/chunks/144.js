"use strict";
exports.id = 144;
exports.ids = [144];
exports.modules = {

/***/ 65687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_CustomButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3866);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const AboutUsInfo = ()=>{
    const handleSCroll = ()=>{};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "flex  flex-col mt-40 md:flex-row  justify-between items-center max-lg:flex-col gap-10 w-full max-container",
        name: "about",
        id: "about",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-1 flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "sect_head text-[24] text-center text-picton-blue",
                        children: "WHO WE ARE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "desc_paragraphs text-gray-500",
                        children: "At Reliable Transit LLC, we are more than just a transportation company – we are a bridge to independence, dignity, and connectivity for individuals with unique mobility challenges and medical needs. With a deep commitment to enhancing the lives of our passengers, we provide exceptional Paratransit and Non-Emergency Medical Transportation Services (NEMTS) that ensure safe, accessible, and reliable journeys for all."
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-1 flex justify-center items-center ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: "/assets/about.jpg",
                    width: 640,
                    height: 538,
                    alt: "About us",
                    className: "w-full"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutUsInfo);


/***/ }),

/***/ 64546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_CoreValues)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(14178);
// EXTERNAL MODULE: ./constants/index.js
var constants = __webpack_require__(99104);
;// CONCATENATED MODULE: ./components/CoreValueCard.jsx



const CoreValueCard = ({ icon, title, content, index })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `flex flex-row p-6 rounded-[20px] ${index !== constants/* coreValues */.M$.length - 1 ? "mb-6" : "mb-0"} core-card`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-1 w-full  flex-col ml-3",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    className: "font-semibold bg-deluge text-white  padding   text-[24px] md:text-[32px] leading-[23px] md:leading-[40.2px] mb-1",
                    children: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "font-normal break-normal text-deluge text-[16px] md:text-[22px] leading-[24px]  md:leading-[30px]     mb-1 mt-8",
                    children: content
                })
            ]
        })
    });
};
/* harmony default export */ const components_CoreValueCard = (CoreValueCard);

;// CONCATENATED MODULE: ./components/CoreValues.jsx



const CoreValues = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: " w-full bg-gallery  flex-col md:flex-row  flex-center",
        name: "coreValues",
        id: "coreValues",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex flex-wrap gap-5  flex-center",
            children: constants/* coreValues */.M$.map((coreValue, index)=>/*#__PURE__*/ jsx_runtime_.jsx(components_CoreValueCard, {
                    ...coreValue,
                    index: index
                }, coreValue.id))
        })
    });
};
/* harmony default export */ const components_CoreValues = (CoreValues);


/***/ }),

/***/ 80832:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\reliabletransit\sections\AboutUs.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;