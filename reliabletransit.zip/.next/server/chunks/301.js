exports.id = 301;
exports.ids = [301];
exports.modules = {

/***/ 32016:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76753));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 703));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99869));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32545));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83634));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13562));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 79694));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61879));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72774));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97686));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 607));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38300));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98707));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50977));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27036));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76455));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83714));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78789));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43680));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90988));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6547));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71234));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66444));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73716));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99749));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99559));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34973));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28605));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91905));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68281));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42396));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35491));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32652));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40551));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10609));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48330));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31341));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9883));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33186));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22580))

/***/ }),

/***/ 3712:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 52987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 56926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31144, 23))

/***/ }),

/***/ 703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_ContactBlock)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/assets/airbnb.png
var airbnb = __webpack_require__(61879);
// EXTERNAL MODULE: ./public/assets/bill.png
var bill = __webpack_require__(38300);
// EXTERNAL MODULE: ./public/assets/binance.png
var binance = __webpack_require__(99869);
// EXTERNAL MODULE: ./public/assets/card.png
var card = __webpack_require__(97686);
// EXTERNAL MODULE: ./public/assets/coinbase.png
var coinbase = __webpack_require__(32545);
// EXTERNAL MODULE: ./public/assets/dropbox.png
var dropbox = __webpack_require__(83634);
// EXTERNAL MODULE: ./public/assets/logo.png
var logo = __webpack_require__(79694);
// EXTERNAL MODULE: ./public/assets/quotes.svg
var quotes = __webpack_require__(13562);
// EXTERNAL MODULE: ./public/assets/robot.png
var robot = __webpack_require__(607);
// EXTERNAL MODULE: ./public/assets/Send.svg
var Send = __webpack_require__(72774);
// EXTERNAL MODULE: ./public/assets/Shield.svg
var Shield = __webpack_require__(27036);
// EXTERNAL MODULE: ./public/assets/Star.svg
var Star = __webpack_require__(50977);
// EXTERNAL MODULE: ./public/assets/menu.svg
var menu = __webpack_require__(98707);
// EXTERNAL MODULE: ./public/assets/close.svg
var assets_close = __webpack_require__(76455);
// EXTERNAL MODULE: ./public/assets/google.svg
var google = __webpack_require__(43680);
// EXTERNAL MODULE: ./public/assets/apple.svg
var apple = __webpack_require__(83714);
// EXTERNAL MODULE: ./public/assets/arrow-up.svg
var arrow_up = __webpack_require__(78789);
// EXTERNAL MODULE: ./public/assets/Discount.svg
var Discount = __webpack_require__(90988);
// EXTERNAL MODULE: ./public/assets/facebook.svg
var facebook = __webpack_require__(6547);
// EXTERNAL MODULE: ./public/assets/instagram.svg
var instagram = __webpack_require__(71234);
// EXTERNAL MODULE: ./public/assets/linkedin.svg
var linkedin = __webpack_require__(66444);
// EXTERNAL MODULE: ./public/assets/twitter.svg
var twitter = __webpack_require__(73716);
// EXTERNAL MODULE: ./public/assets/people01.png
var people01 = __webpack_require__(34973);
// EXTERNAL MODULE: ./public/assets/people02.png
var people02 = __webpack_require__(99749);
// EXTERNAL MODULE: ./public/assets/people03.png
var people03 = __webpack_require__(99559);
// EXTERNAL MODULE: ./public/assets/phone.svg
var phone = __webpack_require__(91905);
// EXTERNAL MODULE: ./public/assets/locationpin.svg
var locationpin = __webpack_require__(28605);
// EXTERNAL MODULE: ./public/assets/destination.svg
var destination = __webpack_require__(42396);
// EXTERNAL MODULE: ./public/assets/docpic.svg
var docpic = __webpack_require__(68281);
// EXTERNAL MODULE: ./public/assets/van.svg
var van = __webpack_require__(35491);
// EXTERNAL MODULE: ./public/assets/office.svg
var office = __webpack_require__(32652);
// EXTERNAL MODULE: ./public/assets/family.svg
var family = __webpack_require__(10609);
// EXTERNAL MODULE: ./public/assets/airplane.svg
var airplane = __webpack_require__(40551);
// EXTERNAL MODULE: ./public/assets/technology.svg
var technology = __webpack_require__(9883);
// EXTERNAL MODULE: ./public/assets/senior.svg
var senior = __webpack_require__(31341);
// EXTERNAL MODULE: ./public/assets/medical.svg
var medical = __webpack_require__(33186);
// EXTERNAL MODULE: ./public/assets/wheelchair.svg
var wheelchair = __webpack_require__(48330);
;// CONCATENATED MODULE: ./public/assets/index.js







































;// CONCATENATED MODULE: ./constants/index.js

const services = [
    {
        id: "service-1",
        icon: medical["default"],
        title: "Doctor Appointment",
        content: "we specialize in transporting individuals to and from medical appointments, ensuring they receive the necessary care."
    },
    {
        id: "service-2",
        icon: senior["default"],
        title: "Senior Transportation",
        content: " we often cater to the elderly in the population, offering assistance  to the intended destination"
    },
    {
        id: "service-3",
        icon: family["default"],
        title: "Family Gatherings",
        content: "we are pleased to provide transportation for patients to attend special events, family gatherings, and celebrations."
    },
    {
        id: "service-4",
        icon: airplane["default"],
        title: "Airport  Transportation",
        content: "we offer transportation to and from airports, catering to travelers with disabilities or mobility challenges."
    },
    {
        id: "service-5",
        icon: office["default"],
        title: "Pharmacy Trips",
        content: " we offer transportation for individuals to pick up prescriptions and medications from pharmacies."
    },
    {
        id: "service-7",
        icon: wheelchair["default"],
        title: "Assistive Devices",
        content: "Our Vehicle are equipped with assistive devices like lifts, ramps, and securement systems to ensure passenger safety."
    }
];
const coreValues = [
    {
        id: "core-1",
        icon: Star["default"],
        title: "Empathy and Compassion ",
        content: "We prioritize empathy and compassion in all our interactions. We understand the unique needs of our passengers and their families, and we are committed to providing caring, patient-centered transportation solutions that respect their dignity and well-being."
    },
    {
        id: "core-2",
        icon: Star["default"],
        title: "Accessibility and Inclusivity",
        content: " We are dedicated to creating an inclusive environment for all individuals, regardless of their abilities or medical conditions."
    },
    {
        id: "core-3",
        icon: Star["default"],
        title: "Reliability and Safety",
        content: "Safety is our utmost priority. We uphold the highest standards of safety in our vehicles, equipment, and operations."
    },
    {
        id: "core-4",
        icon: Star["default"],
        title: "Community Engagement",
        content: " We believe in building strong connections within the communities we serve. We actively engage with local organizations, healthcare facilities, and advocacy groups to understand the evolving needs of our passengers."
    }
];
const stats = [
    {
        id: "stats-1",
        title: "Clients",
        value: "38+"
    },
    {
        id: "stats-2",
        title: " Average Monthly Trips",
        value: "150"
    },
    {
        id: "stats-3",
        title: "Years Serving",
        value: "2"
    }
];
const features = [
    {
        id: "feature-1",
        icon: phone["default"],
        title: "MAKE A CALL / BOOKING ",
        content: "To schedule an appointment, you can either call our dedicated booking line"
    },
    {
        id: "feature-2",
        icon: locationpin["default"],
        title: "SET PICK-UP LOCATION",
        content: "We'll pick you up right from your location ."
    },
    {
        id: "feature-3",
        icon: destination["default"],
        title: "ARRIVE TO DESTINATION",
        content: "We ensure a smooth journey, taking you directly to your destination."
    }
];
const footerLinks = [
    {
        title: "Useful Links",
        links: [
            {
                name: "Book Appointment",
                link: "/#contact"
            },
            {
                name: "Our Services",
                link: "/services"
            },
            {
                name: "About Us",
                link: "/about-us"
            },
            {
                name: "Contact Us",
                link: "/#contact"
            },
            {
                name: "Terms & Services",
                link: "/terms"
            }
        ]
    },
    {
        title: "Quick Links",
        links: [
            {
                name: "Privacy Policy",
                link: "/privacy"
            },
            {
                name: "FAQs",
                link: "/faqs"
            },
            {
                name: "facebook",
                link: ""
            },
            {
                name: "twitter",
                link: "https://www.hoobank.com/blog/"
            },
            {
                name: "LinkedIn",
                link: "https://www.hoobank.com/newsletters/"
            }
        ]
    }
];
const socialMedia = [
    {
        id: "social-media-1",
        icon: instagram["default"],
        link: "https://www.instagram.com/"
    },
    {
        id: "social-media-2",
        icon: facebook["default"],
        link: "https://www.facebook.com/"
    },
    {
        id: "social-media-3",
        icon: twitter["default"],
        link: "https://www.twitter.com/"
    },
    {
        id: "social-media-4",
        icon: linkedin["default"],
        link: "https://www.linkedin.com/"
    }
];
const feedback = [
    {
        id: "feedback-1",
        content: "As a caregiver for my elderly mother, getting her to medical appointments and social events used to be a major challenge.With their reliable and caring drivers, we now have a stress-free solution that has truly been a lifesaver for our family.",
        name: "Herman Jensen",
        title: "Founder & Leader",
        img: people01["default"]
    },
    {
        id: "feedback-2",
        content: " From the moment I make a booking to the time I reach my destination, their drivers and staff provide exceptional service. It's reassuring to know that I can count on them for safe and punctual rides.",
        name: "Steve Mark",
        title: "Founder & Leader",
        img: people02["default"]
    },
    {
        id: "feedback-3",
        content: "Thanks to their caring drivers and accommodating vehicles, I've regained my sense of freedom and can confidently go about my daily activities.",
        name: "Kenn Gallagher",
        title: "Founder & Leader",
        img: people03["default"]
    }
];
const faqsData = [
    {
        id: "que-01",
        question: "What is Paratransit/NEMTS?",
        answer: "Paratransit, also known as Non-Emergency Medical Transportation (NEMTS), refers to specialized transportation services designed to assist individuals with disabilities or medical conditions in reaching their destinations, such as medical appointments, social events, or other essential trips."
    },
    {
        id: "que-02",
        question: "Who is eligible for Paratransit/NEMTS services?",
        answer: "Eligibility criteria vary, but typically include individuals who have disabilities, medical conditions, or mobility challenges that prevent them from using regular public transportation independently."
    },
    {
        id: "que-03",
        question: "How do I determine my eligibility for your services?",
        answer: "Eligibility can be assessed through an application process. Contact our company to obtain the necessary forms and information about the evaluation process."
    },
    {
        id: "que-04",
        question: "How do I schedule a ride with your company?",
        answer: "You can schedule a ride by contacting our booking hotline or using our online booking system. Provide your information, desired pick-up and drop-off locations, and preferred date and time."
    },
    {
        id: "que-05",
        question: "What areas do you serve?",
        answer: "We serve [list of service areas], catering to a wide range of locations to ensure that clients can access transportation where they need it."
    },
    {
        id: "que-06",
        question: "Are your vehicles accessible?",
        answer: "Yes, all our vehicles are equipped to accommodate individuals with mobility challenges. They are designed to provide comfortable and safe transportation for passengers with varying needs."
    },
    {
        id: "que-07",
        question: "Are your drivers trained to assist passengers with disabilities?",
        answer: "Absolutely, our drivers receive specialized training to assist passengers with disabilities, ensuring a supportive and respectful experience throughout the journey."
    },
    {
        id: "que-08",
        question: "Can I bring a companion with me on the ride?",
        answer: "In many cases, companions are allowed to accompany passengers. Please let us know in advance so we can make the necessary arrangements."
    },
    {
        id: "que-09",
        question: "How far in advance should I book a ride?",
        answer: "In many cases, companions are allowed to accompany passengers. Please let us know in advance so we can make the necessary arrangements."
    },
    {
        id: "que-10",
        question: "What are your rates for Paratransit/NEMTS services?",
        answer: "Rates can vary based on factors such as distance, type of trip, and any additional services required. Contact our customer service for detailed information about our pricing structure."
    }
];

// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var index_esm = __webpack_require__(32695);
;// CONCATENATED MODULE: ./components/ContactBlock.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const ContactBlock = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "flex-col w-full flex-center  md:flex-row bg-heroside-bg bg-repeat py-6 px-12 flex-between gap-4 shadow-sm ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "hidden sm:block flex-1 gap-4 flex-center text-deluge md:font-medium md:text-2xl cursor-pointer",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "underline",
                        href: "mailto:info@reliabletransit.org",
                        children: "Email:info@reliabletransit.org"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                    className: "flex flex-row gap-4 text-deluge md:font-medium md:text-xl",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BiPhone */.kq7, {
                            size: "1.5rem"
                        }),
                        "Phone: +(312) 825-1175"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-row md:mt-0 mt-6",
                    children: socialMedia.map((social, index)=>/*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: social.icon,
                            alt: social.id,
                            width: 32,
                            height: 32,
                            className: `object-contain cursor-pointer ${index !== socialMedia.length - 1 ? "mr-6" : "mt-0"}`
                        }, social.id))
                })
            })
        ]
    });
};
/* harmony default export */ const components_ContactBlock = (ContactBlock);


/***/ }),

/***/ 76753:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function NavBar() {
    const [navbar, setNavbar] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full top-0 left-0 right-0 relative",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
            className: "w-full  sticky bg-picton-blue z-10",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "justify-between px-4 mx-auto lg:max-w-7xl md:items-center md:flex md:px-8",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center justify-between py-3 md:py-5 md:block",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        src: "/assets/logo.png",
                                        width: 120,
                                        height: 120,
                                        alt: "Reliable Transit Logo"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "md:hidden",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "p-2 text-gray-700 rounded-md outline-none focus:border-picton-blue-dark focus:border",
                                        onClick: ()=>setNavbar(!navbar),
                                        children: navbar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: "/assets/close.svg",
                                            width: 30,
                                            height: 30,
                                            alt: "logo"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: "/assets/hamburger-menu.svg",
                                            width: 64,
                                            height: 64,
                                            alt: "logo",
                                            className: "focus:border-none active:border-none"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `flex-1 justify-self-center pb-3 mt-8 md:block md:pb-0 md:mt-0 ${navbar ? "p-12 md:p-0 block" : "hidden"}`,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "h-screen md:h-auto items-center justify-center md:flex ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-links",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/",
                                            onClick: ()=>setNavbar(!navbar),
                                            children: "HOME"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-links",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/services",
                                            onClick: ()=>setNavbar(!navbar),
                                            children: "SERVICES"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-links",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "#about",
                                            onClick: ()=>setNavbar(!navbar),
                                            children: "ABOUT US"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-links",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "#contact",
                                            onClick: ()=>setNavbar(!navbar),
                                            children: "CONTACT"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/book-appointment",
                                        className: "flex-center mt-4  md:mt-0   ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            className: "bg-deluge py-4    text-white rounded-full  font-semibold text-xl px-6 hover:bg-deluge-light hover:text-white  ",
                                            children: "BOOK APPOINTMENT"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavBar);


/***/ }),

/***/ 22580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43500);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32695);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const TopBar = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex-col flex-center md:flex-row md:w-full  bg-gallery sticky top-0 left-0 right-0 md:z-10 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex gap-2 w-full flex-col md:flex-center  md:flex-row text-sm  font-normal ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                        className: "flex-1 gap-4 flex-center text-picton-blue md:font-medium md:text-xl cursor-pointer",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__/* .FaRegEnvelope */ .uWG, {
                                size: "1.5rem"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "underline",
                                href: "mailto:info@reliabletransit.org",
                                children: "Email:info@reliabletransit.org"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                        className: "flex gap-4 text-picton-blue md:font-medium md:text-xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__/* .BiPhone */ .kq7, {
                                size: "1.5rem"
                            }),
                            "Phone: (312) 825-1175"
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopBar);


/***/ }),

/***/ 4049:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(7633);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/TopBar.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\reliabletransit\components\TopBar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const TopBar = ((/* unused pure expression or super */ null && (__default__)));
// EXTERNAL MODULE: ./constants/index.js
var constants = __webpack_require__(99104);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(14178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/ContactBlock.jsx
var ContactBlock = __webpack_require__(30906);
;// CONCATENATED MODULE: ./components/Footer.jsx
// import { logo } from '../public/assets/logo'




const Footer = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "footer_sect bg-deluge flex flex-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex  flex-2 md:flex-row px-6 flex-col mb-8 w-full mt-14",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex-1  flex-center flex flex-col justify-start mr-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/assets/logo.png",
                                width: 220,
                                height: 150,
                                alt: "Reliable Transit Logo",
                                className: "object-contain  bg-opacity-10 shadow-sm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-medium text-white text-[18px] leading-[30.8px]  max-w-[310px]",
                                children: "Reliable paratransit and NEMTS services, ensuring seamless transportation solutions for diverse needs."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex-[1.5] w-full flex flex-row flex-center md:flex-start  md:gap-80 gap-14 flex-wrap md:mt-0 mt-10 ",
                        children: constants/* footerLinks */.dk.map((footerLink)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col ss:my-0 my-4 min-w-[150px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: "font-medium text-[18px] md:text-[26px] leading-[30px] text-picton-blue-dark",
                                        children: footerLink.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        children: footerLink.links.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "font-normal text-white text-[18px] leading-[24px]  hover:text-picton-blue",
                                                children: link.name
                                            }, link.name))
                                    })
                                ]
                            }, footerLink.key))
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col flex-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "font-medium text-[24px] text-picton-blue-dark",
                                children: "Contacts"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-white text-[20px] font-medium mb-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "underline",
                                    href: "mailto:info@reliabletransit.org",
                                    children: "Email:info@reliabletransit.org"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-white text-[20px] font-medium md:mb-8",
                                children: "Phone : +(312) 825-1175"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-row md:mt-0 mt-6 py-4 px-4 bg-gallery bg-opacity-2 rounded-full flex-center md:w-full  w-3/5",
                                children: constants/* socialMedia */.LF.map((social, index)=>/*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: social.icon,
                                        alt: social.id,
                                        width: 21,
                                        height: 21,
                                        className: `object-contain cursor-pointer ${index !== constants/* socialMedia */.LF.length - 1 ? "mr-6" : "mt-0"}`
                                    }, social.id))
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full  bg-gallery flex  flex-center md:flex-row flex-col pt-6 border-t-[1px] border-t-gallery   ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-medium text-[18px] leading-[27px] text-center text-deluge px-4",
                        children: "2023 Reliable Transit. All Rights Reserved"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-row md:mt-0 mt-6 py-4 px-4 ",
                        children: constants/* socialMedia */.LF.map((social, index)=>/*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: social.icon,
                                alt: social.id,
                                width: 21,
                                height: 21,
                                className: `object-contain cursor-pointer ${index !== constants/* socialMedia */.LF.length - 1 ? "mr-6" : "mt-0"}`
                            }, social.id))
                    })
                ]
            })
        ]
    });
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./components/Nav.jsx

const Nav_proxy = (0,module_proxy.createProxy)(String.raw`C:\reliabletransit\components\Nav.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Nav_esModule, $$typeof: Nav_$$typeof } = Nav_proxy;
const Nav_default_ = Nav_proxy.default;


/* harmony default export */ const Nav = (Nav_default_);
;// CONCATENATED MODULE: ./app/layout.js





const metadata = {
    title: "Reliable Transit LLC",
    description: "dedicated paratransit company provides safe and comfortable transportation options. Whether for medical appointments or daily activities, trust us for inclusive and accessible travel solutions."
};
const RootLayout = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "main"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                    className: "app",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Nav, {}),
                        children,
                        /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layout = (RootLayout);


/***/ }),

/***/ 30906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\reliabletransit\components\ContactBlock.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 99104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I1: () => (/* binding */ feedback),
/* harmony export */   LF: () => (/* binding */ socialMedia),
/* harmony export */   M$: () => (/* binding */ coreValues),
/* harmony export */   R2: () => (/* binding */ features),
/* harmony export */   dk: () => (/* binding */ footerLinks),
/* harmony export */   ot: () => (/* binding */ stats),
/* harmony export */   uZ: () => (/* binding */ services)
/* harmony export */ });
/* unused harmony export faqsData */
/* harmony import */ var _public_assets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(99515);

const services = [
    {
        id: "service-1",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .medical */ .DB,
        title: "Doctor Appointment",
        content: "we specialize in transporting individuals to and from medical appointments, ensuring they receive the necessary care."
    },
    {
        id: "service-2",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .senior */ .Sh,
        title: "Senior Transportation",
        content: " we often cater to the elderly in the population, offering assistance  to the intended destination"
    },
    {
        id: "service-3",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .family */ .NK,
        title: "Family Gatherings",
        content: "we are pleased to provide transportation for patients to attend special events, family gatherings, and celebrations."
    },
    {
        id: "service-4",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .airplane */ .RI,
        title: "Airport  Transportation",
        content: "we offer transportation to and from airports, catering to travelers with disabilities or mobility challenges."
    },
    {
        id: "service-5",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .office */ .Tl,
        title: "Pharmacy Trips",
        content: " we offer transportation for individuals to pick up prescriptions and medications from pharmacies."
    },
    {
        id: "service-7",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .wheelchair */ .dh,
        title: "Assistive Devices",
        content: "Our Vehicle are equipped with assistive devices like lifts, ramps, and securement systems to ensure passenger safety."
    }
];
const coreValues = [
    {
        id: "core-1",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .star */ .h_,
        title: "Empathy and Compassion ",
        content: "We prioritize empathy and compassion in all our interactions. We understand the unique needs of our passengers and their families, and we are committed to providing caring, patient-centered transportation solutions that respect their dignity and well-being."
    },
    {
        id: "core-2",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .star */ .h_,
        title: "Accessibility and Inclusivity",
        content: " We are dedicated to creating an inclusive environment for all individuals, regardless of their abilities or medical conditions."
    },
    {
        id: "core-3",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .star */ .h_,
        title: "Reliability and Safety",
        content: "Safety is our utmost priority. We uphold the highest standards of safety in our vehicles, equipment, and operations."
    },
    {
        id: "core-4",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .star */ .h_,
        title: "Community Engagement",
        content: " We believe in building strong connections within the communities we serve. We actively engage with local organizations, healthcare facilities, and advocacy groups to understand the evolving needs of our passengers."
    }
];
const stats = [
    {
        id: "stats-1",
        title: "Clients",
        value: "38+"
    },
    {
        id: "stats-2",
        title: " Average Monthly Trips",
        value: "150"
    },
    {
        id: "stats-3",
        title: "Years Serving",
        value: "2"
    }
];
const features = [
    {
        id: "feature-1",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .phone */ .m7,
        title: "MAKE A CALL / BOOKING ",
        content: "To schedule an appointment, you can either call our dedicated booking line"
    },
    {
        id: "feature-2",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .locationpin */ .df,
        title: "SET PICK-UP LOCATION",
        content: "We'll pick you up right from your location ."
    },
    {
        id: "feature-3",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .destination */ .mY,
        title: "ARRIVE TO DESTINATION",
        content: "We ensure a smooth journey, taking you directly to your destination."
    }
];
const footerLinks = [
    {
        title: "Useful Links",
        links: [
            {
                name: "Book Appointment",
                link: "/#contact"
            },
            {
                name: "Our Services",
                link: "/services"
            },
            {
                name: "About Us",
                link: "/about-us"
            },
            {
                name: "Contact Us",
                link: "/#contact"
            },
            {
                name: "Terms & Services",
                link: "/terms"
            }
        ]
    },
    {
        title: "Quick Links",
        links: [
            {
                name: "Privacy Policy",
                link: "/privacy"
            },
            {
                name: "FAQs",
                link: "/faqs"
            },
            {
                name: "facebook",
                link: ""
            },
            {
                name: "twitter",
                link: "https://www.hoobank.com/blog/"
            },
            {
                name: "LinkedIn",
                link: "https://www.hoobank.com/newsletters/"
            }
        ]
    }
];
const socialMedia = [
    {
        id: "social-media-1",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .instagram */ .CR,
        link: "https://www.instagram.com/"
    },
    {
        id: "social-media-2",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .facebook */ .qv,
        link: "https://www.facebook.com/"
    },
    {
        id: "social-media-3",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .twitter */ .km,
        link: "https://www.twitter.com/"
    },
    {
        id: "social-media-4",
        icon: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .linkedin */ .kG,
        link: "https://www.linkedin.com/"
    }
];
const feedback = [
    {
        id: "feedback-1",
        content: "As a caregiver for my elderly mother, getting her to medical appointments and social events used to be a major challenge.With their reliable and caring drivers, we now have a stress-free solution that has truly been a lifesaver for our family.",
        name: "Herman Jensen",
        title: "Founder & Leader",
        img: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .people01 */ .hw
    },
    {
        id: "feedback-2",
        content: " From the moment I make a booking to the time I reach my destination, their drivers and staff provide exceptional service. It's reassuring to know that I can count on them for safe and punctual rides.",
        name: "Steve Mark",
        title: "Founder & Leader",
        img: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .people02 */ .$$
    },
    {
        id: "feedback-3",
        content: "Thanks to their caring drivers and accommodating vehicles, I've regained my sense of freedom and can confidently go about my daily activities.",
        name: "Kenn Gallagher",
        title: "Founder & Leader",
        img: _public_assets__WEBPACK_IMPORTED_MODULE_0__/* .people03 */ .sp
    }
];
const faqsData = [
    {
        id: "que-01",
        question: "What is Paratransit/NEMTS?",
        answer: "Paratransit, also known as Non-Emergency Medical Transportation (NEMTS), refers to specialized transportation services designed to assist individuals with disabilities or medical conditions in reaching their destinations, such as medical appointments, social events, or other essential trips."
    },
    {
        id: "que-02",
        question: "Who is eligible for Paratransit/NEMTS services?",
        answer: "Eligibility criteria vary, but typically include individuals who have disabilities, medical conditions, or mobility challenges that prevent them from using regular public transportation independently."
    },
    {
        id: "que-03",
        question: "How do I determine my eligibility for your services?",
        answer: "Eligibility can be assessed through an application process. Contact our company to obtain the necessary forms and information about the evaluation process."
    },
    {
        id: "que-04",
        question: "How do I schedule a ride with your company?",
        answer: "You can schedule a ride by contacting our booking hotline or using our online booking system. Provide your information, desired pick-up and drop-off locations, and preferred date and time."
    },
    {
        id: "que-05",
        question: "What areas do you serve?",
        answer: "We serve [list of service areas], catering to a wide range of locations to ensure that clients can access transportation where they need it."
    },
    {
        id: "que-06",
        question: "Are your vehicles accessible?",
        answer: "Yes, all our vehicles are equipped to accommodate individuals with mobility challenges. They are designed to provide comfortable and safe transportation for passengers with varying needs."
    },
    {
        id: "que-07",
        question: "Are your drivers trained to assist passengers with disabilities?",
        answer: "Absolutely, our drivers receive specialized training to assist passengers with disabilities, ensuring a supportive and respectful experience throughout the journey."
    },
    {
        id: "que-08",
        question: "Can I bring a companion with me on the ride?",
        answer: "In many cases, companions are allowed to accompany passengers. Please let us know in advance so we can make the necessary arrangements."
    },
    {
        id: "que-09",
        question: "How far in advance should I book a ride?",
        answer: "In many cases, companions are allowed to accompany passengers. Please let us know in advance so we can make the necessary arrangements."
    },
    {
        id: "que-10",
        question: "What are your rates for Paratransit/NEMTS services?",
        answer: "Rates can vary based on factors such as distance, type of trip, and any additional services required. Contact our customer service for detailed information about our pricing structure."
    }
];


/***/ }),

/***/ 99515:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  RI: () => (/* reexport */ airplane),
  mY: () => (/* reexport */ destination),
  qv: () => (/* reexport */ facebook),
  NK: () => (/* reexport */ family),
  CR: () => (/* reexport */ instagram),
  kG: () => (/* reexport */ linkedin),
  df: () => (/* reexport */ locationpin),
  DB: () => (/* reexport */ medical),
  Tl: () => (/* reexport */ office),
  hw: () => (/* reexport */ people01),
  $$: () => (/* reexport */ people02),
  sp: () => (/* reexport */ people03),
  m7: () => (/* reexport */ phone),
  Sh: () => (/* reexport */ senior),
  h_: () => (/* reexport */ Star),
  km: () => (/* reexport */ twitter),
  dh: () => (/* reexport */ wheelchair)
});

// UNUSED EXPORTS: airbnb, apple, arrowUp, bill, binance, card, close, coinbase, discount, docpic, dropbox, google, logo, menu, quotes, robot, send, shield, technology, van

;// CONCATENATED MODULE: ./public/assets/airbnb.png
/* harmony default export */ const airbnb = ({"src":"/_next/static/media/airbnb.5bed46d9.png","height":120,"width":386,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAOElEQVR4nGN0dHAzZ2Bg4GNgZDjB8J/BBMjmBeKvQPwHiHlBCoKADCYgvgnEWkAMkmQB4r9AzAsARK0JN4J1mhQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/bill.png
/* harmony default export */ const bill = ({"src":"/_next/static/media/bill.6b97dc06.png","height":1038,"width":1120,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA0ElEQVR42mMozC9lWb5yPSsDEMyYvXBid9/kA8FB4cckxdTCGNBBW1PnmbzUnP8m2sb/FeS1asGCcWlZc9LSc+bG+YfN8q2sf+41ecZ/265J/7WTs2rACiq8Yv/npOf+D/QL+W/nFfDfNTnriltLj2dkUbkKWMGMzv4/yQlpfyRE1H8Auf+BeA+KvbUTOv9FRcf/DfQP+Tth6qT/K5avfPLjx8+QL1++xH///sOUQU/LzBiozrCmvs7m3Zd3Ld+/f+959+79lPfv38/98OFDNADFKF1aq+80hgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/binance.png
/* harmony default export */ const binance = ({"src":"/_next/static/media/binance.6fce11aa.png","height":78,"width":385,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAANklEQVR42mNwdHCLd3R0cwHSgSDs5ODmCWV7A3EYA1AyDoidHB3cQYK+QBwMxEFA7OXk4BYMAD95EXe/N3oFAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/card.png
/* harmony default export */ const card = ({"src":"/_next/static/media/card.f8322197.png","height":899,"width":1026,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA2UlEQVR42mOAgf///7PUX7zGn1JSlZ1aWFbhYO2cbahhkM5gZGC5VdnV+6isusFSBtsgGa+g0C++fsH/TQ2t/6ua2v9n8PUJ+h8cGvXfydnjP4NXmKaqhtEzIU7J//wqWj/45LV/MhiZ2q6wdvLYpGlq0xszfa6QgYbRK+XwgP+yJub/pcSV/jOAwc4DvEBSG4hNgLiWIdCvVN87LEySgdOHAQSSkzJzu3sm/O/u6v3d0tL2v7CwdD4DMigpq01funz1/82bN3/ftHnz/8mTJ69gAILJ06ZzAAABTU1Gx1IK1wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/coinbase.png
/* harmony default export */ const coinbase = ({"src":"/_next/static/media/coinbase.f1f63ef2.png","height":83,"width":379,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAOElEQVR4nGN0dHDTY2BgYGVkYOD/D8RA9m8gvg/E7EDMAlJQDGQwMzIwcv1n+P8FyOaB4j9AzAYAL4EJVTLZ0F4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/dropbox.png
/* harmony default export */ const dropbox = ({"src":"/_next/static/media/dropbox.cf29f19b.png","height":76,"width":386,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAOklEQVR4nBXKIQ4AEBhA4d8RRMVZKE4mOqEi2gRFMJvhCd/2wlPehSQiDRkHAwYd+w+RqCjQsJhYuA++lw09XceY2AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.dcd66cfc.png","height":900,"width":1100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAwElEQVR42mOAgdbZpyZuOPLw49rDDz+2zDo1kQEZdC08N+nc/Y//n378/f/V59//Lzz89L970bnJUOlGxf2XXv56//3v/3nnP/19+uHX3/9AsPfiy98MDM1KDBKRG51uPPkEEvt3+fmP/6cefQezbzz+9F8jdpMz0IRapUNXXv0CiT569/Pv848QEw5feQ00oUGZAQQ6FpydfPflt/9PP//9//zL3/8gdseCc1MYkEHzzJOT1x559AmEm2aehEsCAAdph6IjL8nbAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/quotes.svg
/* harmony default export */ const quotes = ({"src":"/_next/static/media/quotes.e3ea52be.svg","height":28,"width":43,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/robot.png
/* harmony default export */ const robot = ({"src":"/_next/static/media/robot.c35bf057.png","height":1348,"width":1338,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA7klEQVR42mMIOHfLt/fZ62MMQNDaO8+grnGqLYi9eetBRgYQMDp2gzt47ymHqvY57dMnL/u2eNnW/03d84pAcvOX72AGK8pqmhKRt2Hf/57dJ/7v2HH4yOVr1/2WrF/LwgADS7paxdsWrFvTNGfD/97JK/9P7JlbCxKvmbGJCazAPSLTJzS25kdiVt8318im1upLtwr+///PBDeh5f9/gZbpa0JW7D8X8P//f5nC7Ydj5t57KQFXkFDZp5tV03t+ytb9/+cevfI/LLbsdkrezK8RcbPvwBVZ+cTbqOgHFen5VjkAuay2WtmBbp7VxwCSPGvBWrtBCgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/Send.svg
/* harmony default export */ const Send = ({"src":"/_next/static/media/Send.0f66c8ac.svg","height":32,"width":33,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/Shield.svg
/* harmony default export */ const Shield = ({"src":"/_next/static/media/Shield.09c69a90.svg","height":32,"width":28,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/Star.svg
/* harmony default export */ const Star = ({"src":"/_next/static/media/Star.02698d4f.svg","height":32,"width":33,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/menu.svg
/* harmony default export */ const menu = ({"src":"/_next/static/media/menu.dd0b9695.svg","height":64,"width":64,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/close.svg
/* harmony default export */ const assets_close = ({"src":"/_next/static/media/close.c008d9af.svg","height":64,"width":64,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/google.svg
/* harmony default export */ const google = ({"src":"/_next/static/media/google.99a8ab11.svg","height":44,"width":145,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/apple.svg
/* harmony default export */ const apple = ({"src":"/_next/static/media/apple.fb5cbb36.svg","height":43,"width":129,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/arrow-up.svg
/* harmony default export */ const arrow_up = ({"src":"/_next/static/media/arrow-up.0975ed47.svg","height":21,"width":22,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/Discount.svg
/* harmony default export */ const Discount = ({"src":"/_next/static/media/Discount.953a0111.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/facebook.svg
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.714df14c.svg","height":21,"width":21,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/instagram.svg
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.9cc5ad59.svg","height":21,"width":21,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/linkedin.svg
/* harmony default export */ const linkedin = ({"src":"/_next/static/media/linkedin.813a11f9.svg","height":21,"width":21,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/twitter.svg
/* harmony default export */ const twitter = ({"src":"/_next/static/media/twitter.3b83ecd8.svg","height":19,"width":23,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/people01.png
/* harmony default export */ const people01 = ({"src":"/_next/static/media/people01.85d6f24e.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+ATFkXwDPq6Ep5tzqmMjHxjnn8dQAP0cyx/T7/mi2zK/XAVBkaikOBfLFNDU9EfjIyQDp7+8A5yrmAFJMWO8OEgE7AXWVo8HSv6U+IAD3+mFLVAbd4eMAm5yN+lOVeAYBGAXCAXueq/rLs5sFRzIoACX9BQDk6ugAwN7dADNaKgANJ//7AXaZpfrJppAFGAoDACkN/QCuwdYAIywtAElsXQAaJA77AXCRn8Gzm5E+6Or4+pOGgAaZkYcAydPR+ktUWgZ2eG3CAVVueyq9rqnE7uTcEZu41QC0pJoAsaSRAA0QGe/z8Oc7AUBVYAD77espxb61mKGzyDkWGRwAVkM2x/Px5mkAAADWKL98pQ0mlKsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/people02.png
/* harmony default export */ const people02 = ({"src":"/_next/static/media/people02.9c744388.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+Adv4/wAAAAAo//0AmObb1zoJDA4AFR0bxvn5/2kBAgHXAdPs9igJDQnF18PAEqRoQQALISoAVIGjACczMu/18/c7Adbx/L8DAwNAwZB1+iMNBgb9/gIA2wga+khhaQb6+f3CAd77//kA/AAGzZaBAAP79wAA9/YAIFRqABIsKAD48/77Ab3T3PnCwcEGE97BACkaHAD8/QAAwfMHAERYXgAeISD7AQAAAL8AAABAaUQe+kk2QAba8AIAdJag+hMADQaUu7jCAVldXyino6HFh4GAEi0lIwBbaXkADxIPAAMCAu/f3dM7AQAAAAAAAAAoq62ymAkKCjpMSUQAJyctx/L1+Gjn5ObXnfdq2x0qig8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/people03.png
/* harmony default export */ const people03 = ({"src":"/_next/static/media/people03.7f5a57de.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAgElEQVR42gWAKwoCURSG/+3cARdh1OJCRtyE3WQQk4hBEAWNtsOMRcRkmglWQbjJ1z2i3yDUDcHk8oE9A1IZ2rFDTg+xigRV1mKWvhwYppy36e599hRsGDHl5/r4kTNXKhbcwIXVbNOLC+sEfxNZHeecWFJCfAShIuxs7BOPRoYaJo5gIgihfWoAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/phone.svg
/* harmony default export */ const phone = ({"src":"/_next/static/media/phone.eadf37c0.svg","height":150,"width":150,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/locationpin.svg
/* harmony default export */ const locationpin = ({"src":"/_next/static/media/locationpin.fc9c465c.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/destination.svg
/* harmony default export */ const destination = ({"src":"/_next/static/media/destination.52ad86b5.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/docpic.svg
/* harmony default export */ const docpic = ({"src":"/_next/static/media/docpic.143ac503.svg","height":140,"width":140,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/van.svg
/* harmony default export */ const van = ({"src":"/_next/static/media/van.7bd26c63.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/office.svg
/* harmony default export */ const office = ({"src":"/_next/static/media/office.09155b7f.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/family.svg
/* harmony default export */ const family = ({"src":"/_next/static/media/family.7bc00510.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/airplane.svg
/* harmony default export */ const airplane = ({"src":"/_next/static/media/airplane.3e562340.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/technology.svg
/* harmony default export */ const technology = ({"src":"/_next/static/media/technology.76bf047e.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/senior.svg
/* harmony default export */ const senior = ({"src":"/_next/static/media/senior.88f273cc.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/medical.svg
/* harmony default export */ const medical = ({"src":"/_next/static/media/medical.fa60c71a.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/wheelchair.svg
/* harmony default export */ const wheelchair = ({"src":"/_next/static/media/wheelchair.8548c16a.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/index.js








































/***/ }),

/***/ 90988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Discount.953a0111.svg","height":32,"width":32,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 72774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Send.0f66c8ac.svg","height":32,"width":33,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 27036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Shield.09c69a90.svg","height":32,"width":28,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 50977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Star.02698d4f.svg","height":32,"width":33,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 61879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/airbnb.5bed46d9.png","height":120,"width":386,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAOElEQVR4nGN0dHAzZ2Bg4GNgZDjB8J/BBMjmBeKvQPwHiHlBCoKADCYgvgnEWkAMkmQB4r9AzAsARK0JN4J1mhQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 40551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/airplane.3e562340.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 83714:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/apple.fb5cbb36.svg","height":43,"width":129,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 78789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow-up.0975ed47.svg","height":21,"width":22,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 38300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/bill.6b97dc06.png","height":1038,"width":1120,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA0ElEQVR42mMozC9lWb5yPSsDEMyYvXBid9/kA8FB4cckxdTCGNBBW1PnmbzUnP8m2sb/FeS1asGCcWlZc9LSc+bG+YfN8q2sf+41ecZ/265J/7WTs2rACiq8Yv/npOf+D/QL+W/nFfDfNTnriltLj2dkUbkKWMGMzv4/yQlpfyRE1H8Auf+BeA+KvbUTOv9FRcf/DfQP+Tth6qT/K5avfPLjx8+QL1++xH///sOUQU/LzBiozrCmvs7m3Zd3Ld+/f+959+79lPfv38/98OFDNADFKF1aq+80hgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 99869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/binance.6fce11aa.png","height":78,"width":385,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAANklEQVR42mNwdHCLd3R0cwHSgSDs5ODmCWV7A3EYA1AyDoidHB3cQYK+QBwMxEFA7OXk4BYMAD95EXe/N3oFAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 97686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/card.f8322197.png","height":899,"width":1026,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA2UlEQVR42mOAgf///7PUX7zGn1JSlZ1aWFbhYO2cbahhkM5gZGC5VdnV+6isusFSBtsgGa+g0C++fsH/TQ2t/6ua2v9n8PUJ+h8cGvXfydnjP4NXmKaqhtEzIU7J//wqWj/45LV/MhiZ2q6wdvLYpGlq0xszfa6QgYbRK+XwgP+yJub/pcSV/jOAwc4DvEBSG4hNgLiWIdCvVN87LEySgdOHAQSSkzJzu3sm/O/u6v3d0tL2v7CwdD4DMigpq01funz1/82bN3/ftHnz/8mTJ69gAILJ06ZzAAABTU1Gx1IK1wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 76455:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/close.c008d9af.svg","height":64,"width":64,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 32545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/coinbase.f1f63ef2.png","height":83,"width":379,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAOElEQVR4nGN0dHDTY2BgYGVkYOD/D8RA9m8gvg/E7EDMAlJQDGQwMzIwcv1n+P8FyOaB4j9AzAYAL4EJVTLZ0F4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 42396:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/destination.52ad86b5.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 68281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/docpic.143ac503.svg","height":140,"width":140,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 83634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/dropbox.cf29f19b.png","height":76,"width":386,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAOklEQVR4nBXKIQ4AEBhA4d8RRMVZKE4mOqEi2gRFMJvhCd/2wlPehSQiDRkHAwYd+w+RqCjQsJhYuA++lw09XceY2AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 6547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/facebook.714df14c.svg","height":21,"width":21,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 10609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/family.7bc00510.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 43680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/google.99a8ab11.svg","height":44,"width":145,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 71234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/instagram.9cc5ad59.svg","height":21,"width":21,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 66444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/linkedin.813a11f9.svg","height":21,"width":21,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 28605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/locationpin.fc9c465c.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 79694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.dcd66cfc.png","height":900,"width":1100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAwElEQVR42mOAgdbZpyZuOPLw49rDDz+2zDo1kQEZdC08N+nc/Y//n378/f/V59//Lzz89L970bnJUOlGxf2XXv56//3v/3nnP/19+uHX3/9AsPfiy98MDM1KDBKRG51uPPkEEvt3+fmP/6cefQezbzz+9F8jdpMz0IRapUNXXv0CiT569/Pv848QEw5feQ00oUGZAQQ6FpydfPflt/9PP//9//zL3/8gdseCc1MYkEHzzJOT1x559AmEm2aehEsCAAdph6IjL8nbAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 33186:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/medical.fa60c71a.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 98707:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/menu.dd0b9695.svg","height":64,"width":64,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 32652:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/office.09155b7f.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 34973:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/people01.85d6f24e.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+ATFkXwDPq6Ep5tzqmMjHxjnn8dQAP0cyx/T7/mi2zK/XAVBkaikOBfLFNDU9EfjIyQDp7+8A5yrmAFJMWO8OEgE7AXWVo8HSv6U+IAD3+mFLVAbd4eMAm5yN+lOVeAYBGAXCAXueq/rLs5sFRzIoACX9BQDk6ugAwN7dADNaKgANJ//7AXaZpfrJppAFGAoDACkN/QCuwdYAIywtAElsXQAaJA77AXCRn8Gzm5E+6Or4+pOGgAaZkYcAydPR+ktUWgZ2eG3CAVVueyq9rqnE7uTcEZu41QC0pJoAsaSRAA0QGe/z8Oc7AUBVYAD77espxb61mKGzyDkWGRwAVkM2x/Px5mkAAADWKL98pQ0mlKsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 99749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/people02.9c744388.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+Adv4/wAAAAAo//0AmObb1zoJDA4AFR0bxvn5/2kBAgHXAdPs9igJDQnF18PAEqRoQQALISoAVIGjACczMu/18/c7Adbx/L8DAwNAwZB1+iMNBgb9/gIA2wga+khhaQb6+f3CAd77//kA/AAGzZaBAAP79wAA9/YAIFRqABIsKAD48/77Ab3T3PnCwcEGE97BACkaHAD8/QAAwfMHAERYXgAeISD7AQAAAL8AAABAaUQe+kk2QAba8AIAdJag+hMADQaUu7jCAVldXyino6HFh4GAEi0lIwBbaXkADxIPAAMCAu/f3dM7AQAAAAAAAAAoq62ymAkKCjpMSUQAJyctx/L1+Gjn5ObXnfdq2x0qig8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 99559:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/people03.7f5a57de.png","height":96,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAgElEQVR42gWAKwoCURSG/+3cARdh1OJCRtyE3WQQk4hBEAWNtsOMRcRkmglWQbjJ1z2i3yDUDcHk8oE9A1IZ2rFDTg+xigRV1mKWvhwYppy36e599hRsGDHl5/r4kTNXKhbcwIXVbNOLC+sEfxNZHeecWFJCfAShIuxs7BOPRoYaJo5gIgihfWoAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 91905:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/phone.eadf37c0.svg","height":150,"width":150,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 13562:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/quotes.e3ea52be.svg","height":28,"width":43,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/robot.c35bf057.png","height":1348,"width":1338,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA7klEQVR42mMIOHfLt/fZ62MMQNDaO8+grnGqLYi9eetBRgYQMDp2gzt47ymHqvY57dMnL/u2eNnW/03d84pAcvOX72AGK8pqmhKRt2Hf/57dJ/7v2HH4yOVr1/2WrF/LwgADS7paxdsWrFvTNGfD/97JK/9P7JlbCxKvmbGJCazAPSLTJzS25kdiVt8318im1upLtwr+///PBDeh5f9/gZbpa0JW7D8X8P//f5nC7Ydj5t57KQFXkFDZp5tV03t+ytb9/+cevfI/LLbsdkrezK8RcbPvwBVZ+cTbqOgHFen5VjkAuay2WtmBbp7VxwCSPGvBWrtBCgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 31341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/senior.88f273cc.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 9883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/technology.76bf047e.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 73716:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/twitter.3b83ecd8.svg","height":19,"width":23,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 35491:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/van.7bd26c63.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 48330:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/wheelchair.8548c16a.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 7633:
/***/ (() => {



/***/ })

};
;