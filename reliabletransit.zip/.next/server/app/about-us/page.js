(() => {
var exports = {};
exports.id = 554;
exports.ids = [554];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 88753:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'about-us',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 77984)), "C:\\reliabletransit\\app\\about-us\\page.js"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4049)), "C:\\reliabletransit\\app\\layout.js"],
          
        }
      ]
      }.children;
const pages = ["C:\\reliabletransit\\app\\about-us\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/about-us/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/about-us/page",
        pathname: "/about-us",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 97096:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99869));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32545));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83634));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13562));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 79694));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61879));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72774));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97686));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 607));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38300));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98707));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50977));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27036));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76455));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83714));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78789));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43680));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90988));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6547));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71234));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66444));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73716));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99749));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99559));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34973));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28605));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91905));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68281));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42396));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35491));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32652));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40551));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10609));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48330));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31341));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9883));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33186));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 65687));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 65253))

/***/ }),

/***/ 65253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CustomButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3866);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const AboutUsBanner = ()=>{
    const handleSCroll = ()=>{};
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "banner bg-cover w-full bg-contact-bg bg-deluge-light",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col py-6 px-4 items-start justify-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                    className: "banner__title",
                    children: [
                        '"We Are Dedicated To"',
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                            className: "text-orange-400"
                        }),
                        " Safe Journeys"
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "banner__subtitle ",
                    children: [
                        "Enabling Seamless Journeys ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " Our Commitment to Accessible and Inclusive Paratransit Solutions"
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    title: "Book A Ride",
                    containerStyles: "bg-picton-blue text-white rounded-full mt-10",
                    handleClick: handleSCroll
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutUsBanner);


/***/ }),

/***/ 77984:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/AboutBanner.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\reliabletransit\components\AboutBanner.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const AboutBanner = (__default__);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(62947);
;// CONCATENATED MODULE: ./components/AboutUsHeader.jsx


const AboutHeader = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " mt-10  mb-10 text-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "heading2",
                children: "ABOUT US"
            })
        })
    });
};
/* harmony default export */ const AboutUsHeader = (AboutHeader);

// EXTERNAL MODULE: ./sections/AboutUs.jsx
var AboutUs = __webpack_require__(80832);
// EXTERNAL MODULE: ./components/CTA.jsx
var CTA = __webpack_require__(16692);
// EXTERNAL MODULE: ./components/CoreValues.jsx + 1 modules
var CoreValues = __webpack_require__(64546);
;// CONCATENATED MODULE: ./sections/Mission.jsx


const Mission = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "bg-picton-blue padding-y padding-x rounded-[20px]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-center  flex-col",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "heading2 text-center text-white",
                    children: "Our mission"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "lg:max-w-lg text-white items-start text-xl justify-center leading-[2.5] ",
                    children: "At Reliable Transit LLC, our mission is to empower individuals with disabilities, seniors, and those in need of specialized medical transportation by providing safe, accessible, and compassionate services. We are dedicated to fostering independence, ensuring dignity, and fostering connectivity through our reliable Paratransit and Non-Emergency Medical Transportation Services (NEMTS). With unwavering commitment, we bridge gaps, remove barriers, and create inclusive transportation solutions that enrich lives, strengthen communities, and enable our passengers to embrace every journey with confidence."
                })
            ]
        })
    });
};
/* harmony default export */ const sections_Mission = (Mission);

;// CONCATENATED MODULE: ./app/about-us/page.js








const page_AboutUs = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " flex flex-col flex-center w-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(AboutBanner, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(AboutUsHeader, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(AboutUs/* default */.ZP, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "heading2 text-center",
                children: "Mission"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sections_Mission, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "heading2 text-center",
                children: "Core Values"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CoreValues/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(CTA/* default */.Z, {})
        ]
    });
};
/* harmony default export */ const page = (page_AboutUs);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [478,35,301,202,144], () => (__webpack_exec__(88753)));
module.exports = __webpack_exports__;

})();