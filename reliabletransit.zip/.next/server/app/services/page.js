(() => {
var exports = {};
exports.id = 469;
exports.ids = [469];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 58325:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'services',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85136)), "C:\\reliabletransit\\app\\services\\page.js"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4049)), "C:\\reliabletransit\\app\\layout.js"],
          
        }
      ]
      }.children;
const pages = ["C:\\reliabletransit\\app\\services\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/services/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/services/page",
        pathname: "/services",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 54026:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66827));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 703));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82100));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99869));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32545));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83634));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13562));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 79694));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61879));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72774));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97686));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 607));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38300));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98707));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50977));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27036));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76455));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83714));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78789));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43680));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90988));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6547));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71234));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66444));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73716));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99749));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99559));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34973));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28605));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91905));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68281));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42396));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35491));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32652));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40551));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10609));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48330));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31341));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9883));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33186))

/***/ }),

/***/ 82100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CustomButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3866);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Servicebanner = ()=>{
    const handleSCroll = ()=>{};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex-center bg-deluge w-full flex-col md:flex-row mr-0",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 flex-col py-6 px-4 items-start justify-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        className: "md:text-4xl uppercase text-white md:font-extrabold text-[32px] font-medium",
                        children: [
                            "Customized Rides for Your Unique Needs",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            " Discover Our Services"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "banner__subtitle ",
                        children: [
                            "Enabling Seamless Journeys ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            " Our Commitment to Accessible and Inclusive Paratransit Solutions"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-8 flex-row  flex-center md:mb-20",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                title: "Book A Ride",
                                containerStyles: "hidden sm:block text-white text-bold uppercase border-white border-4 rounded-full mt-10",
                                handleClick: handleSCroll
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                title: "CALL: +(312) 825-1175",
                                containerStyles: "bg-picton-blue text-white font-medium rounded-full mt-10 py-2 px2 text-normal",
                                className: "",
                                handleClick: handleSCroll
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-1 h-540 w-full fill-container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "hero__image-container",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "hero__image opacity-10 hidden sm:block",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/assets/pattern.png",
                                alt: "hero",
                                fill: true,
                                className: "h-[540] w-full object-cover"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "hero__image-overlay"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Servicebanner);


/***/ }),

/***/ 85136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/CTA.jsx
var CTA = __webpack_require__(16692);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(62947);
;// CONCATENATED MODULE: ./components/SectionHeader.jsx


const SectionHeader = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " mt-10  mb-10 text-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "heading-title uppercase text-deluge",
                children: "Services"
            })
        })
    });
};
/* harmony default export */ const components_SectionHeader = (SectionHeader);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/ServiceBanner.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\reliabletransit\components\ServiceBanner.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const ServiceBanner = (__default__);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(14178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./constants/index.js
var constants = __webpack_require__(99104);
;// CONCATENATED MODULE: ./components/ServiceCards.jsx



const ServiceCard = ({ icon, title, content, index })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "shadow-sm",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: ` bg-gallery flex-row p-6 md:rounded-[40px] ${index !== constants/* services */.uZ.length - 1 ? "mb-0" : "mb-0"} service-card`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `w-[120px] h-[120px] rounded mt-4 flex-center `,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: icon,
                        width: 120,
                        height: 120,
                        alt: "icon"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-1 mt-2 flex-col ml-3",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            className: "text-center text-picton-blue font-semibold  uppercase text-[20px] md:text-[24px] leading-[23px] mb-1",
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-normal text-center break-normal text-gray-500 text-[18px] leading-[24px] mb-1",
                            children: content
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const ServiceCards = (ServiceCard);

;// CONCATENATED MODULE: ./components/ServiceCardList.jsx



const ServiceCardList = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "flex flex-col md:flex-row",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex flex-wrap gap-5 flex-center",
            children: constants/* services */.uZ.map((service, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ServiceCards, {
                    ...service,
                    index: index
                }, service.id))
        })
    });
};
/* harmony default export */ const components_ServiceCardList = (ServiceCardList);

;// CONCATENATED MODULE: ./sections/ServicePerks.jsx


const ServicePerks = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "flex mt-40 flex-col md:flex-row flex-center gap-10 w-full ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex-1 w-full ml-4 flex-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/contact.jpg",
                    width: 640,
                    height: 540,
                    alt: "service perks",
                    className: "w-full blur-md filter brightness-40"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex-1 flex-col flex-center bg-purple-600",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "sect_head text-center text-deluge",
                        children: " WE ARE "
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " w-full md:flex-start md:pl-40 flex-col gap-6 ",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " w-full flex gap-4 md:py-4 py-2 ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "assets/check.svg",
                                        alt: "checkmark",
                                        width: 32,
                                        height: 32
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "list_text ",
                                        children: "Accessible"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-4 md:py-4 py-2 ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "assets/check.svg",
                                        alt: "checkmark",
                                        width: 32,
                                        height: 32
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "list_text ",
                                        children: "Reliable"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-4 md:py-4 py-2 ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "assets/check.svg",
                                        alt: "checkmark",
                                        width: 32,
                                        height: 32
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "list_text ",
                                        children: "Professional"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-4 md:py-4 py-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "assets/check.svg",
                                        alt: "checkmark",
                                        width: 32,
                                        height: 32
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "list_text ",
                                        children: "Safety Oriented "
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-4 md:py-4 py-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "assets/check.svg",
                                        alt: "checkmark",
                                        width: 32,
                                        height: 32
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "list_text ",
                                        children: "Flexible"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const sections_ServicePerks = (ServicePerks);

;// CONCATENATED MODULE: ./components/ServiceStatement.jsx


const ServiceStatement = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full flex-center flex-col mt-10 md:mt-10 mb-10 shadow-xs shadow-deluge rounded-[20px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "heading-title uppercase py-2 text-deluge",
                children: "Our Services"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "desc_paragraphs md:text-center text-gray-600 md:max-w-6xl max-w-4xl",
                children: "We serve all of your most important non-emergency medical transportation needs, driving you to and from healthcare facilities, doctors’ clinics, nursing homes, physical therapy, and many other destinations where you may be receiving vital treatments needed to maintain\xa0optimal\xa0health."
            })
        ]
    });
};
/* harmony default export */ const components_ServiceStatement = (ServiceStatement);

// EXTERNAL MODULE: ./app/contact/ContactForm.jsx
var ContactForm = __webpack_require__(70604);
// EXTERNAL MODULE: ./components/ContactBlock.jsx
var ContactBlock = __webpack_require__(30906);
;// CONCATENATED MODULE: ./app/services/page.js










const Services = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex-col  w-full flex-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ServiceBanner, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_ServiceStatement, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(sections_ServicePerks, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_SectionHeader, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_ServiceCardList, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(CTA/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "font-semibold xs:text-[48px] text-[24] md:text-[48px] text-deluge xs:leading-[76.8px] leading-[66.8px] w-full text-center py-6",
                        children: "GET IN TOUCH WITH US"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ContactBlock/* default */.ZP, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(ContactForm/* default */.ZP, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Services);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [478,35,301,46,202], () => (__webpack_exec__(58325)));
module.exports = __webpack_exports__;

})();