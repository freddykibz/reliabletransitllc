(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 86819:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 52732:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35526)), "C:\\reliabletransit\\app\\page.js"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4049)), "C:\\reliabletransit\\app\\layout.js"],
          
        }
      ]
      }.children;
const pages = ["C:\\reliabletransit\\app\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 93486:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66827));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94745));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99869));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32545));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83634));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13562));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 79694));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61879));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72774));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97686));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 607));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38300));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98707));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50977));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27036));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76455));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83714));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78789));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43680));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90988));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6547));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71234));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66444));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73716));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99749));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99559));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34973));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28605));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91905));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68281));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42396));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35491));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32652));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40551));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10609));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48330));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31341));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9883));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33186));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 703));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3985));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 65687))

/***/ }),

/***/ 94745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _CustomButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3866);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Hero = ()=>{
    const handleSCroll = ()=>{};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "hero w-full flex-col bg-deluge ",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 pt-36 bg-service-bg bg-center bg-opacity-25 padding-x",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "md:text-6xl text-2xl uppercase text-white md:font-extrabold font-medium bg-picton-blue-dark bg-opacity-25",
                        children: "Empowering Mobility Independence"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "max-w-xl  text-[27px] text-center text-picton-blue lg:text-left lg:max-w-md mt-5 bg-deluge rounded-[10px]",
                        children: "Your Ride Your Schedule"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButton__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        title: "Book A Ride",
                        containerStyles: "bg-picton-blue text-white rounded-full mt-10 mb-10",
                        handleClick: handleSCroll
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " flex-1 bg-heroside",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "hero__image-container",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "hero__image  hidden sm:block",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: "/assets/bg-heroside.png",
                                alt: "hero",
                                fill: true,
                                className: "object-fill"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "hero__image-overlay"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 3985:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_cloudinary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14835);
/* harmony import */ var next_cloudinary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_cloudinary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_cloudinary_dist_cld_video_player_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77222);
/* harmony import */ var next_cloudinary_dist_cld_video_player_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_cloudinary_dist_cld_video_player_css__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


// import videoBg from '../public/assets/bg-video.mp4';
const Slider = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "md:top-32 left-0 right-0  z-5 w-full",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_cloudinary__WEBPACK_IMPORTED_MODULE_1__.CldVideoPlayer, {
                    width: "1920",
                    height: "1080",
                    src: "https://res.cloudinary.com/dnwzxgsuc/video/upload/v1693404983/bg-vid_fdatxc.mp4",
                    autoplayMode: "on-scroll",
                    "data-cld-autoplay-mode": "on-scroll",
                    loop: true,
                    autoPlay: true,
                    preload: "auto",
                    colors: {
                        accent: "#EEECEE",
                        base: "#8370B7",
                        text: "#29B2EC"
                    }
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "hidden sm:block vid-content",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: " hidden sm:block md:text-8xl text-2xl uppercase top-20 left-0 sm:top-4 xs:0 text-white  md:font-extrabold font-medium bg-picton-blue-dark bg-opacity-25 abolute",
                    children: "Empowering Mobility Independence"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Slider);


/***/ }),

/***/ 35526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/Button.jsx
var Button = __webpack_require__(13302);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(14178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./constants/index.js
var constants = __webpack_require__(99104);
;// CONCATENATED MODULE: ./components/FeatureCard.jsx



const FeatureCard = ({ icon, title, content, index })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `flex flex-row w-full  md:w-[550px] bg-gallery p-6 rounded-[20px] ${index !== constants/* features */.R2.length - 1 ? "mb-6" : "mb-0"} feature-card`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `w-[64px] h-[64px] rounded-full flex-center bg-dimBlue`,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: icon,
                    alt: "star",
                    width: 64,
                    height: 64,
                    className: "w-[50%] h-[50%] object-contain"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-1  flex-col ml-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "font-medium text-picton-blue md:text-[26px] text-24 leading-[23px] mb-4",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-normal break-normal break-words text-gray-500 text-[20px] leading-[24px] mb-1",
                        children: content
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_FeatureCard = (FeatureCard);

;// CONCATENATED MODULE: ./components/Business.jsx




const Business = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "flex-col business_container flex-center gap-10 relative",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "section_info ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "sect_head text-[24] text-center",
                        children: "WE MAKE IT EASY! "
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "md:text-[26px] text-[24]  text-gray-600   font-normal  max-w-[540px] mt-5 ",
                        children: " Moreover, Company X's well-trained and compassionate drivers undergo specialized training to offer courteous assistance, making clients feel comfortable and valued throughout their travels."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " flex-1 flex-col mt-8",
                children: constants/* features */.R2.map((feature, index)=>/*#__PURE__*/ jsx_runtime_.jsx(components_FeatureCard, {
                        ...feature,
                        index: index
                    }, feature.id))
            })
        ]
    });
};
/* harmony default export */ const components_Business = (Business);

// EXTERNAL MODULE: ./components/CTA.jsx
var CTA = __webpack_require__(16692);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/Hero.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\reliabletransit\components\Hero.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Hero = ((/* unused pure expression or super */ null && (__default__)));
;// CONCATENATED MODULE: ./components/Stats.jsx


const Stats = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "stat  bg-gallery  bg-opacity-50  py-12  flex-wrap flex-row  md:flex-row",
        children: constants/* stats */.ot.map((stat)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-1 flex-center flex-col md:flex-row m-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "md:font-bold font-normal  xs:text-[40px] text-picton-blue  text-[24px] md:text-[40px] xs:leading-[53px] leading-[24px]  md:leading-[43px]",
                        children: stat.value
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-normal xs:text-[20px]  text-[] md:text-[15px] xs:leading-[26px] leading-[21px] uppercase ml-3",
                        children: stat.title
                    })
                ]
            }, stat.id))
    });
};
/* harmony default export */ const components_Stats = (Stats);

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(62947);
// EXTERNAL MODULE: ./public/assets/index.js + 37 modules
var assets = __webpack_require__(99515);
;// CONCATENATED MODULE: ./components/FeedBackCard.jsx




const FeedBackCard = ({ content, name, title, img })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between flex-col px-10 md:py-6  rounded-[20px] md:max-w-[470px] md:mr-10 sm:mr-5 mr-0 my-5 bg-deluge md:bg-white shadow-sm shadow-gallery-dark ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "font-normal text-[20px] md:text-[26px] text-white  md:text-gray-500  leading-[32px] my-10",
                children: content
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row flex-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: img,
                        width: 48,
                        height: 48,
                        alt: "Profile Image",
                        className: "rounded-full "
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-col    ml-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            className: "font-semibold text-[20px] leading-[32px]",
                            children: name
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_FeedBackCard = (FeedBackCard);

;// CONCATENATED MODULE: ./components/Testimonials.jsx



const Testimonials = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "flex-center sm:py-16 py-6 flex-col relative ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute z-[0] w-[60%] h-[60%] -right-[50%] rounded-full gradient"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full flex justify-between items-center md:flex-row flex-col sm:mb:16 mb-6 relative z-[1]",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "font-semibold xs:text-[48px] text-[20] md:text-[48px] text-deluge xs:leading-[76.8px] leading-[66.8px] w-full text-center",
                    children: '" WHAT OUR CLIENTS SAY "'
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-wrap sm:justify-center  justify-center w-full feedback-container",
                children: constants/* feedback */.I1.map((card)=>/*#__PURE__*/ jsx_runtime_.jsx(components_FeedBackCard, {
                        ...card
                    }, card.id))
            })
        ]
    });
};
/* harmony default export */ const components_Testimonials = (Testimonials);

;// CONCATENATED MODULE: ./components/ValueStatement.jsx


const ValueStatement = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full flex-center flex-col bg-deluge mt-0 md:py-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "heading-title text-white py-2 ",
                children: "WHY RELIABLE TRANSIT LLC"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "desc_paragraphs text-white md:text-center md:max-w-6xl ",
                children: "Reliable Transit LLC, we redefine transportation accessibility. With our unwavering commitment to excellence, we provide seamless paratransit and NEMT services that prioritize your comfort, safety, and convenience. Our well-maintained fleet, compassionate staff, and innovative technology ensure that your journey is not only reliable but also tailored to your unique\xa0needs.\xa0"
            })
        ]
    });
};
/* harmony default export */ const components_ValueStatement = (ValueStatement);

// EXTERNAL MODULE: ./app/contact/ContactForm.jsx
var ContactForm = __webpack_require__(70604);
// EXTERNAL MODULE: ./components/ContactBlock.jsx
var ContactBlock = __webpack_require__(30906);
;// CONCATENATED MODULE: ./components/slider.jsx

const slider_proxy = (0,module_proxy.createProxy)(String.raw`C:\reliabletransit\components\slider.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: slider_esModule, $$typeof: slider_$$typeof } = slider_proxy;
const slider_default_ = slider_proxy.default;


/* harmony default export */ const slider = (slider_default_);
// EXTERNAL MODULE: ./components/CoreValues.jsx + 1 modules
var CoreValues = __webpack_require__(64546);
// EXTERNAL MODULE: ./sections/AboutUs.jsx
var AboutUs = __webpack_require__(80832);
;// CONCATENATED MODULE: ./app/page.js












const Home = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(slider, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_ValueStatement, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Business, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Stats, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "bg-opacity-25 w-full font-semibold xs:text-[48px] text-[24] md:text-[48px] text-deluge xs:leading-[76.8px] leading-[66.8px]  text-center py-6",
                children: "ABOUT US"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AboutUs/* default */.ZP, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "font-semibold xs:text-[48px] text-[24] md:text-[48px] text-deluge xs:leading-[76.8px] leading-[66.8px] w-full text-center py-6",
                children: "OUR CORE VALUES"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CoreValues/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Testimonials, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(CTA/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "font-semibold xs:text-[48px] text-[24] md:text-[48px] text-deluge xs:leading-[76.8px] leading-[66.8px] w-full text-center py-6",
                children: "GET IN TOUCH WITH US"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ContactBlock/* default */.ZP, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ContactForm/* default */.ZP, {})
        ]
    });
};
/* harmony default export */ const page = (Home);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [478,35,53,301,46,202,144], () => (__webpack_exec__(52732)));
module.exports = __webpack_exports__;

})();