import React from 'react'

const ContactForm = () => {
  return (
    <div>
        <form>
            
        </form>
    </div>
  )
}

export default ContactForm;