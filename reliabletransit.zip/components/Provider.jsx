import React from 'react'

const Provider = () => {
  return (
    <div>Provider</div>
  )
}

export default Provider