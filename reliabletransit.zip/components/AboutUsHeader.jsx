import React from 'react'


const AboutHeader = () => {
  return (
    <section>
        <div className=' mt-10  mb-10 text-center'>
            <h1 className='heading2'>ABOUT US</h1>
        </div>
    </section>
  )
}

export default AboutHeader;