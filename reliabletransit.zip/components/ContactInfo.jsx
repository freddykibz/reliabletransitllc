import React from 'react'

const ContactInfo = () => {
  return (
    <div>
        
        <div></div>
    </div>
  )
}

export default ContactInfo