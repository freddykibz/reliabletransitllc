import React from 'react'

const CTAButton = () => {
  return (
    <div>CTAButton</div>
  )
}

export default CTAButton