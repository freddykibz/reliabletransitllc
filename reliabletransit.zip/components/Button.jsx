import React from 'react'

const Button = () => {
  return (
  
    <button type='button' className='cta_button mt-24 rounded '>
        BOOK APPOINTMENT
    </button>
  )
}

export default Button