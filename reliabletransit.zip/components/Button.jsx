import React from 'react'

const Button = () => {
  return (
  
    <button type='button' className='cta_button md:mt-24  mt-10 rounded-full flex-center'>
        BOOK APPOINTMENT
    </button>
  )
}

export default Button